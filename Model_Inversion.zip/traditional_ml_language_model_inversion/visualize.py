import json, os
import matplotlib.pyplot as plt
import numpy as np
from config import ARTIFACT_DIR, FIGURE_DIR

def main():
    os.makedirs(FIGURE_DIR, exist_ok=True)
    path = ARTIFACT_DIR / "metrics.json"
    if not path.exists():
        raise SystemExit("Run python train.py first.")
    data = json.load(open(path))
    names = list(data["results"])
    metrics = ["exact_match_accuracy", "token_f1_micro", "mean_retrieval_cosine_similarity"]
    fig, ax = plt.subplots(figsize=(9,5))
    x = np.arange(len(names)); width = 0.24
    for i, metric in enumerate(metrics):
        vals = [data["results"][n].get(metric, 0) for n in names]
        ax.bar(x + (i-1)*width, vals, width, label=metric.replace("_"," "))
    ax.set_xticks(x, names); ax.set_ylim(0,1); ax.set_ylabel("Score")
    ax.set_title("Traditional ML inversion approximation")
    ax.legend(fontsize=8); fig.tight_layout()
    fig.savefig(FIGURE_DIR / "model_comparison.png", dpi=160)
    print("Saved figures/model_comparison.png")
if __name__ == "__main__":
    main()
