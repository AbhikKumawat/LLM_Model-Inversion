# Project Report: Traditional-ML Approximation to Language Model Inversion

## 1. Research question
Can numerical features derived from a frozen language model's next-token probability distribution help a classical ML system identify a prompt among a known set of prompts?

## 2. Scope and ethics
Prompts are synthetic and classroom-oriented. Do not use private, confidential, or unauthorized prompts. This project is not a privacy attack and does not establish that prompts can generally be recovered from model outputs.

## 3. Method
For prompt \(x\), a frozen causal language model returns logits \(z_i\) for next-token vocabulary item \(i\). Temperature-adjusted probabilities are

\[
p_i(T)=\frac{\exp(z_i/T)}{\sum_j\exp(z_j/T)}.
\]

For top-\(k\), all but the \(k\) largest probabilities are set to zero (the retained mass is not renormalized). The feature vector concatenates the vocabulary probability vector and summary statistics such as entropy \(H(p)=-\sum_i p_i\log p_i\), maximum probability, nonzero count, probability mass and top-five values.

TruncatedSVD maps the high-dimensional probability vector to a lower-dimensional representation. The feature representation is passed to a traditional regressor. The target is the prompt's TF-IDF vector, with unigram and bigram features. Ridge regression minimizes

\[
\|Y-XW\|_2^2+\alpha\|W\|_2^2.
\]

Random Forest regression is the second baseline. Each model predicts a TF-IDF-like vector; cosine nearest-neighbor retrieval returns the closest prompt in the training corpus.

## 4. Experimental protocol
The synthetic prompt set has 100 rows. `train_test_split` uses a fixed random seed and a 75/25 split. Run both baselines on the same split. Repeat with different corpus sizes, temperatures and top-k values. Save each run's JSON metrics before the next run overwrites it.

## 5. Evaluation
Exact match asks whether the retrieved string equals the held-out target. Token precision/recall/F1 measure lexical overlap. Cosine similarity measures how close the predicted text vector is to the retrieved candidate. These metrics answer different questions and should be reported together.

## 6. Interpretation and limitations
This is deliberately a closed-bank retrieval baseline, not open-ended text generation. With unique held-out strings excluded from the retrieval bank, exact-match accuracy is expected to be zero unless duplicate strings occur. The other metrics can still quantify similarity. The same next-token distribution may arise from different contexts; one distribution is not an invertible encoding of an entire prompt. Tokenization, model choice, context truncation, temperature and top-k all affect features. A small synthetic corpus is not evidence of real-world prompt recovery.

The paper and official repository use a more sophisticated method that this classical ML pipeline does not reproduce. Do not describe this project as a replication of the paper.

## 7. Future work
- Add multiple prompt families and a larger authorized corpus.
- Evaluate retrieval only among prompts from held-out templates, and separately evaluate candidate-bank retrieval.
- Compare probability features with a TF-IDF-only lexical baseline.
- Try calibrated probability summaries, Jensen-Shannon distance, and a nearest-neighbor baseline directly on probability features.
- Use multiple context positions or multiple queries per prompt, clearly documenting what information the system receives.
- Report confidence intervals across multiple fixed seeds.
