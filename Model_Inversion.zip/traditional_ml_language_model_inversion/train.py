import argparse, json, os
import numpy as np
from sklearn.model_selection import train_test_split
from config import *
from dataset import make_prompts
from features import ProbabilityExtractor
from model import RidgeInverter, RandomForestInverter
from evaluate import evaluate_texts

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=100, help="Number of synthetic prompts")
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--top-k", type=int, default=20)
    parser.add_argument("--model", default=MODEL_NAME)
    args = parser.parse_args()
    os.makedirs(ARTIFACT_DIR, exist_ok=True)
    df = make_prompts().head(args.limit).reset_index(drop=True)
    train_idx, test_idx = train_test_split(np.arange(len(df)), test_size=0.25,
                                            random_state=SEED)
    extractor = ProbabilityExtractor(args.model, MAX_LENGTH)
    # Features are cached so the pretrained model need not be rerun for each ML experiment.
    X = extractor.extract(df.prompt.tolist(), args.temperature, args.top_k)
    np.savez_compressed(ARTIFACT_DIR / "features.npz", X=X, prompts=df.prompt.to_numpy(),
                        train_idx=train_idx, test_idx=test_idx)
    train_text = df.prompt.iloc[train_idx].tolist()
    test_text = df.prompt.iloc[test_idx].tolist()
    results = {}
    for name, cls in [("ridge", RidgeInverter), ("random_forest", RandomForestInverter)]:
        model = cls().fit(X[train_idx], train_text)
        pred, sim = model.predict(X[test_idx])
        results[name] = evaluate_texts(test_text, pred, sim)
        print(f"\n{name}\n", json.dumps(results[name], indent=2))
    with open(ARTIFACT_DIR / "metrics.json", "w") as f:
        json.dump({"settings": vars(args), "results": results}, f, indent=2)
    print("\nSaved artifacts/features.npz and artifacts/metrics.json")

if __name__ == "__main__":
    main()
