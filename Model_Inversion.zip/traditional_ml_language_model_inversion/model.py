"""Traditional ML inversion approximations; no neural network is trained here."""
import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import NearestNeighbors
from features import split_features

class RidgeInverter:
    """Regress probability-derived features to TF-IDF text vectors, then retrieve nearest prompt."""
    def __init__(self, n_components=64, alpha=2.0, seed=42):
        self.n_components = n_components
        self.alpha = alpha
        self.seed = seed

    def fit(self, X, texts):
        probs, stats = split_features(X)
        self.svd = TruncatedSVD(n_components=min(self.n_components, probs.shape[1]-1),
                                random_state=self.seed)
        Z = self.svd.fit_transform(probs)
        self.scaler = StandardScaler()
        Z = np.hstack([self.scaler.fit_transform(Z), stats])
        self.feature_scaler = StandardScaler()
        Z = self.feature_scaler.fit_transform(Z)
        self.vectorizer = TfidfVectorizer(ngram_range=(1,2), lowercase=True,
                                          token_pattern=r"(?u)\b\w+\b")
        Y = self.vectorizer.fit_transform(texts).toarray()
        self.regressor = Ridge(alpha=self.alpha)
        self.regressor.fit(Z, Y)
        self.corpus_texts = list(texts)
        self.corpus_vectors = self.vectorizer.transform(texts)
        self.corpus_nn = NearestNeighbors(n_neighbors=1, metric="cosine").fit(self.corpus_vectors)
        return self

    def predict(self, X):
        probs, stats = split_features(X)
        Z = self.svd.transform(probs)
        Z = np.hstack([self.scaler.transform(Z), stats])
        Z = self.feature_scaler.transform(Z)
        predicted_text_vectors = self.regressor.predict(Z)
        # Exact text is not generated: the output is the closest item in the known prompt bank.
        distances, indices = self.corpus_nn.kneighbors(predicted_text_vectors)
        return [self.corpus_texts[i] for i in indices[:, 0]], 1.0 - distances[:, 0]

class RandomForestInverter:
    """Alternative classical regressor with the same TF-IDF target and nearest-prompt decoding."""
    def __init__(self, n_components=32, trees=120, seed=42):
        self.n_components, self.trees, self.seed = n_components, trees, seed

    def fit(self, X, texts):
        probs, stats = split_features(X)
        self.svd = TruncatedSVD(n_components=min(self.n_components, probs.shape[1]-1),
                                random_state=self.seed)
        Z = np.hstack([self.svd.fit_transform(probs), stats])
        self.vectorizer = TfidfVectorizer(ngram_range=(1,2), lowercase=True,
                                          token_pattern=r"(?u)\b\w+\b")
        Y = self.vectorizer.fit_transform(texts).toarray()
        self.regressor = RandomForestRegressor(n_estimators=self.trees, min_samples_leaf=2,
                                               random_state=self.seed, n_jobs=-1)
        self.regressor.fit(Z, Y)
        self.corpus_texts = list(texts)
        self.corpus_nn = NearestNeighbors(n_neighbors=1, metric="cosine").fit(
            self.vectorizer.transform(texts))
        return self

    def predict(self, X):
        probs, stats = split_features(X)
        Z = np.hstack([self.svd.transform(probs), stats])
        pred = self.regressor.predict(Z)
        distances, indices = self.corpus_nn.kneighbors(pred)
        return [self.corpus_texts[i] for i in indices[:, 0]], 1.0 - distances[:, 0]
