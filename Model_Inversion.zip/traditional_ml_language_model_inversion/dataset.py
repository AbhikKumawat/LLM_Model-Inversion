"""Small, authorized synthetic/public-style prompt corpus for a classroom experiment."""
import pandas as pd

def make_prompts():
    # Synthetic prompts: no private or user-supplied content.
    subjects = ["a city park", "a science teacher", "a small bakery", "a robot",
                "a community garden", "a space telescope", "a school library",
                "a mountain village", "an electric bicycle", "a local museum"]
    tasks = [
        "Write a short description of {}.",
        "Explain three benefits of {}.",
        "Suggest a creative project involving {}.",
        "Give a beginner-friendly guide to {}.",
        "List possible challenges related to {}.",
        "Write a cheerful announcement about {}.",
        "Compare two approaches to improving {}.",
        "Create five questions about {}.",
        "Describe a future version of {}.",
        "Write a brief fictional scene featuring {}.",
    ]
    rows = []
    for si, subject in enumerate(subjects):
        for ti, task in enumerate(tasks):
            rows.append({"prompt_id": f"p{si:02d}_{ti:02d}", "prompt": task.format(subject),
                         "family": f"task_{ti}"})
    return pd.DataFrame(rows)

if __name__ == "__main__":
    df = make_prompts()
    print(df.head(10).to_string(index=False))
    print(f"Created {len(df)} synthetic prompts.")
