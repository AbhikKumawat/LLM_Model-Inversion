"""Extract next-token probability features. The language model is frozen and used only as a sensor."""
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

class ProbabilityExtractor:
    def __init__(self, model_name="distilgpt2", max_length=128, device=None):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        # This pretrained neural LM only supplies probabilities; no neural inversion/training occurs.
        self.model = AutoModelForCausalLM.from_pretrained(model_name)
        self.model.eval()
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.max_length = max_length
        self.vocab_size = self.model.config.vocab_size

    @torch.inference_mode()
    def distribution(self, text, temperature=1.0, top_k=20):
        if temperature <= 0:
            raise ValueError("temperature must be > 0")
        encoded = self.tokenizer(text, return_tensors="pt", truncation=True,
                                 max_length=self.max_length).to(self.device)
        logits = self.model(**encoded).logits[0, -1].float().cpu().numpy()
        logits = logits / float(temperature)
        logits = logits - logits.max()
        probs = np.exp(logits)
        probs /= probs.sum()
        # Keep only top-k entries; preserve their probability mass rather than renormalizing.
        if top_k is not None and 0 < top_k < len(probs):
            idx = np.argpartition(probs, -top_k)[-top_k:]
            sparse = np.zeros_like(probs)
            sparse[idx] = probs[idx]
            probs = sparse
        return probs

    def extract(self, prompts, temperature=1.0, top_k=20):
        rows = []
        for text in prompts:
            p = self.distribution(text, temperature, top_k)
            positive = p[p > 0]
            entropy = float(-(positive * np.log(positive + 1e-15)).sum())
            top = np.sort(p)[-5:][::-1]
            stats = [entropy, float(p.max()), float((p > 0).sum()),
                     float(p.sum()), float(np.linalg.norm(p))]
            stats += list(top)
            rows.append(np.concatenate([p.astype(np.float32), np.array(stats, np.float32)]))
        return np.vstack(rows).astype(np.float32)

def split_features(X):
    """Separate vocab-sized probability vector from 10 scalar distribution statistics."""
    return X[:, :-10], X[:, -10:]
