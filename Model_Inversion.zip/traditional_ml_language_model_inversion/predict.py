"""Demo: query a trained prompt-bank approximation using cached feature rows."""
import numpy as np
from config import ARTIFACT_DIR
from features import ProbabilityExtractor
from model import RidgeInverter

def main():
    data = np.load(ARTIFACT_DIR / "features.npz", allow_pickle=True)
    X, prompts = data["X"], data["prompts"].tolist()
    tr, te = data["train_idx"], data["test_idx"]
    model = RidgeInverter().fit(X[tr], [prompts[i] for i in tr])
    # Use a held-out row to demonstrate retrieval from the known training bank.
    idx = int(te[0])
    pred, sim = model.predict(X[idx:idx+1])
    print("Input prompt (for demonstration/evaluation):", prompts[idx])
    print("Retrieved candidate:", pred[0])
    print("Cosine similarity:", round(float(sim[0]), 4))
    print("Note: this is closed-bank retrieval, not free-form prompt generation.")

if __name__ == "__main__":
    main()
