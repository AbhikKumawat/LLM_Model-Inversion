# Traditional-ML Language Model Inversion Approximation

**Scope:** educational, closed-corpus approximation. A frozen pretrained causal LM provides next-token probabilities; all inversion/regression/retrieval components are classical scikit-learn models. No neural network is trained for inversion.

## Scientific framing (read this first)

The paper [Language Model Inversion](https://arxiv.org/abs/2311.13647) and its [official vec2text implementation](https://github.com/jxmorris12/vec2text) use a different, deep-learning-oriented approach. This project does **not** reproduce that method. It investigates a smaller question: can probability-derived features help retrieve a prompt from a known bank of synthetic prompts?

A next-token distribution is conditional on the prompt and tokenizer, but one distribution generally does not uniquely determine the whole prompt. Different prompts can induce similar distributions, and the distribution can omit much of the earlier context. Therefore, the system predicts a TF-IDF representation and retrieves the nearest prompt from the training bank. It does not freely reconstruct arbitrary text. The reported exact-match score measures whether the retrieved bank item equals the held-out prompt; it is not proof that inversion is generally possible.

## Files

- `config.py`: reproducibility and default settings.
- `dataset.py`: 100 synthetic prompts, no personal data.
- `features.py`: frozen-model next-token probabilities and summary statistics.
- `model.py`: Ridge regression and Random Forest regression, followed by cosine nearest-neighbor decoding.
- `train.py`: fixed-seed train/test split and evaluation.
- `evaluate.py`: exact match and token-overlap precision/recall/F1.
- `predict.py`: demonstration on a held-out example.
- `visualize.py`: metric comparison chart.
- `report.md`: methodology, mathematics, interpretation, limitations and future work.

## Run locally

Python 3.10+ recommended.

```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
python train.py
python visualize.py
python predict.py
```

The first run downloads `distilgpt2` and its tokenizer from Hugging Face. A CPU works but can be slow. The pretrained model is only used to produce probability information; it is frozen and no gradient training is performed. If you cannot download model weights, the feature-extraction stage cannot run offline; use a cached model or an approved alternative.

## Google Colab

1. Create a new notebook and upload/extract this project ZIP, or clone/copy its files into the notebook.
2. Run `!pip install -r requirements.txt`.
3. Run `!python train.py --limit 100 --temperature 1.0 --top-k 20`.
4. Run `!python visualize.py`, then display `figures/model_comparison.png`.
5. Inspect `artifacts/metrics.json`.

## Experiments

```bash
python train.py --limit 40 --temperature 1.0 --top-k 20
python train.py --limit 80 --temperature 1.0 --top-k 20
python train.py --limit 100 --temperature 0.7 --top-k 20
python train.py --limit 100 --temperature 1.5 --top-k 20
python train.py --limit 100 --temperature 1.0 --top-k 5
python train.py --limit 100 --temperature 1.0 --top-k 50
```

Each run overwrites the same artifact files, so copy `artifacts/metrics.json` after each run or change output filenames before running multiple conditions. Compare results in a table in your report. Use the same seed and test protocol for fair comparisons. With a small synthetic dataset, results are noisy; do not claim broad generalization.

## Metrics

- **Exact-match accuracy:** fraction of predictions identical to the target prompt.
- **Token precision/recall/F1:** overlap of token multisets; these are lexical overlap measures, not semantic correctness.
- **Mean retrieval cosine similarity:** cosine similarity between predicted TF-IDF representation and the retrieved prompt vector, used as a retrieval diagnostic.

## Important implementation notes

- Features are a vocabulary-sized probability vector plus 10 scalar statistics (entropy, max probability, nonzero count, mass, L2 norm, and top five values). Top-k masking makes the vector sparse.
- TruncatedSVD reduces the probability vector to a compact representation. Ridge or Random Forest regression predicts a TF-IDF vector of the prompt; cosine nearest-neighbor retrieval maps that vector back to a known prompt.
- This is a *closed-bank retrieval* setup. The test prompts are held out from fitting the regression, but they are not candidates in the retrieval bank. Thus the system cannot output the exact held-out prompt unless it is identical to a training prompt; exact match can be zero by design when all prompt strings are unique. That is a useful limitation to report, not something to hide.
- The probability source is a pretrained neural language model, but the inversion model is strictly traditional ML. If the course interprets “no deep learning” as forbidding even using a pretrained LM to obtain probabilities, this project requires a probability source supplied by the instructor or synthetic probability features instead.
