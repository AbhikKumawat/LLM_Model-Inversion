from pathlib import Path
SEED = 42
DATA_DIR = Path("data")
ARTIFACT_DIR = Path("artifacts")
FIGURE_DIR = Path("figures")
MODEL_NAME = "distilgpt2"  # probability source only; not the inversion model
MAX_LENGTH = 128
TOP_K = 20
TEMPERATURE = 1.0
SVD_COMPONENTS = 64
