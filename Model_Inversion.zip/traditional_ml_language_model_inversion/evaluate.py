import re
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

def tokens(s):
    return re.findall(r"\b\w+\b", s.lower())

def token_prf(reference, hypothesis):
    """Micro token overlap scores; repeated tokens are counted using multisets."""
    from collections import Counter
    r, h = Counter(tokens(reference)), Counter(tokens(hypothesis))
    overlap = sum((r & h).values())
    p = overlap / max(sum(h.values()), 1)
    rec = overlap / max(sum(r.values()), 1)
    f1 = 2*p*rec/max(p+rec, 1e-12)
    return p, rec, f1

def evaluate_texts(y_true, y_pred, similarities=None):
    exact = float(np.mean([a == b for a,b in zip(y_true,y_pred)]))
    scores = np.array([token_prf(a,b) for a,b in zip(y_true,y_pred)])
    out = {"exact_match_accuracy": exact,
           "token_precision_micro": float(scores[:,0].mean()),
           "token_recall_micro": float(scores[:,1].mean()),
           "token_f1_micro": float(scores[:,2].mean())}
    if similarities is not None:
        out["mean_retrieval_cosine_similarity"] = float(np.mean(similarities))
    return out
